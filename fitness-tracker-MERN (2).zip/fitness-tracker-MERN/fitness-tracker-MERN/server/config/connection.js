const mongoose = require("mongoose");

// mongoose.set("strictQuery", false);
// // mongodb+srv://tusharkapil20:tushar@cluster0.wnefsop.mongodb.net/?retryWrites=true&w=majority
// mongoose.connect(
//   "",
//   {
//     useNewUrlParser: true,
//     useUnifiedTopology: true,
//   },
//   (err) => {
//     if (err) throw err;
//     console.log("Connected to MongoDB!");
//   }
// );
mongoose.set("strictQuery", false);
const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/demox', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("Database is connected");
  } catch (error) {
    console.error("Database Connection Error:"); // Log the error message
  }
};

module.exports = connectDB;
