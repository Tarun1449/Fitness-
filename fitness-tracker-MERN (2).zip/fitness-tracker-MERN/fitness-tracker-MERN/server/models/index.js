const User = require("./User");
const Resistance = require("./Resistance");
const Cardio = require("./Cardio");

module.exports = { User, Resistance, Cardio };
