const express = require("express");
const path = require("path");
const routes = require("./routes");
// const db = require("./config/connectDB");
const mongoose = require('mongoose');
const PORT = process.env.PORT || 3001;
const app = express();

app.use(express.urlencoded({ extended: true }));
app.use(express.json());

// Serve up static assets
if (process.env.NODE_ENV === "production") {
  app.use(express.static(path.join(__dirname, "../client/build")));
}

// app.get('*', (req, res) => {
//   res.sendFile(path.join(__dirname, '../client/build/index.html'));
// });

app.use(routes);

mongoose.set("strictQuery", false);
const connectDB = async () => {
  try {
    await mongoose.connect('mongodb://127.0.0.1:27017/demox', {
      useNewUrlParser: true,
      useUnifiedTopology: true,
    });
    console.log("Database is connected");
  } catch (error) {
    console.error("Database Connection Error:"); // Log the error message
  }
};
connectDB();

  app.listen(PORT, () => {
    console.log(`API server running on port ${PORT}!`);
  });

